import { useApp } from '../context/AppContext';
import type { ModuloAcceso } from '../types';

const ICONOS: Record<ModuloAcceso['icono'], JSX.Element> = {
  notas: (
    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
      <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" />
      <path d="M14 3v5h5" />
      <path d="M9 13h6M9 17h6" />
    </svg>
  ),
  vitales: (
    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
      <path d="M3 12h4l2-6 4 12 2-6h6" />
    </svg>
  ),
  medicamentos: (
    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
      <rect x="3.5" y="3.5" width="17" height="17" rx="4" />
      <path d="M8 12h8M12 8v8" />
    </svg>
  ),
  pacientes: (
    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  ),
};

const MODULOS: ModuloAcceso[] = [
  {
    id: 'evolucion',
    titulo: 'Notas de Enfermería',
    descripcion: 'Registra observaciones clínicas y evolución diaria de cada residente.',
    icono: 'notas',
  },
  {
    id: 'signos_vitales',
    titulo: 'Signos Vitales',
    descripcion: 'Presión arterial, frecuencia cardíaca, temperatura y saturación de oxígeno.',
    icono: 'vitales',
  },
  {
    id: 'medicacion',
    titulo: 'Medicamentos',
    descripcion: 'Documenta la entrega y dosificación de medicamentos por residente.',
    icono: 'medicamentos',
  },
  {
    id: 'pacientes',
    titulo: 'Gestión de Pacientes',
    descripcion: 'Ver lista completa de pacientes y su información básica.',
    icono: 'pacientes',
  },
];

export default function DashboardView() {
  const { usuarioActual, metricas, seleccionarModulo } = useApp();

  const nombreUsuario = usuarioActual?.nombre || 'Usuario';

  return (
    <div className="dashboard">
      <section className="dashboard__bienvenida">
        <h2>Hola, {nombreUsuario}</h2>
        <p>Este es el resumen de tu hogar geriátrico para hoy. Elige un módulo para comenzar a registrar.</p>
      </section>

      {metricas && (
        <section className="dashboard__resumen">
          <div className="tarjeta-resumen">
            <span className="tarjeta-resumen__valor">{metricas.totalPacientes}</span>
            <span className="tarjeta-resumen__etiqueta">Pacientes activos</span>
          </div>
          <div className="tarjeta-resumen tarjeta-resumen--observacion">
            <span className="tarjeta-resumen__valor">{metricas.pacientesEnObservacion}</span>
            <span className="tarjeta-resumen__etiqueta">En observación</span>
          </div>
          <div className="tarjeta-resumen tarjeta-resumen--critico">
            <span className="tarjeta-resumen__valor">{metricas.pacientesCriticos}</span>
            <span className="tarjeta-resumen__etiqueta">Estado crítico</span>
          </div>
          <div className="tarjeta-resumen">
            <span className="tarjeta-resumen__valor">{metricas.registrosHoy}</span>
            <span className="tarjeta-resumen__etiqueta">Registros hoy</span>
          </div>
        </section>
      )}

      <section className="dashboard__modulos">
        <h3>Módulos de registro</h3>
        <div className="dashboard__grid-tarjetas">
          {MODULOS.map((modulo) => (
            <button
              key={modulo.id}
              type="button"
              className="tarjeta-modulo"
              onClick={() => seleccionarModulo(modulo.id as any)}
            >
              <span className="tarjeta-modulo__icono">{ICONOS[modulo.icono]}</span>
              <span className="tarjeta-modulo__titulo">{modulo.titulo}</span>
              <span className="tarjeta-modulo__descripcion">{modulo.descripcion}</span>
              <span className="tarjeta-modulo__flecha" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M9 6l6 6-6 6" />
                </svg>
              </span>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
