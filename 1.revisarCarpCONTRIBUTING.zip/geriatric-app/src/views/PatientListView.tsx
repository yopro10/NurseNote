import { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import type { EstadoPaciente } from '../types';

const CLASE_ESTADO: Record<EstadoPaciente, string> = {
  Estable: 'badge badge--verde',
  'En Observación': 'badge badge--ambar',
  Crítico: 'badge badge--rojo',
};

export default function PatientListView() {
  const { pacientes, moduloSeleccionado, buscarPacientes, seleccionarPaciente, irADashboard } = useApp();
  const [query, setQuery] = useState('');

  // Búsqueda funcional con pequeño debounce para no disparar en cada tecla
  useEffect(() => {
    const timeout = setTimeout(() => {
      buscarPacientes(query);
    }, 200);
    return () => clearTimeout(timeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  return (
    <div className="lista-pacientes">
      <div className="lista-pacientes__cabecera">
        <button type="button" className="enlace-volver" onClick={irADashboard}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M15 18l-6-6 6-6" />
          </svg>
          Menú principal
        </button>
        <h2>{moduloSeleccionado ?? 'Pacientes activos'}</h2>
        <p>Selecciona un residente para crear un nuevo registro en este módulo.</p>
      </div>

      <div className="buscador">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="11" cy="11" r="7" />
          <path d="m21 21-4.3-4.3" />
        </svg>
        <input
          type="text"
          placeholder="Buscar por nombre o número de cédula…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      <div className="tabla-contenedor">
        <table className="tabla">
          <thead>
            <tr>
              <th>Residente</th>
              <th>Cédula</th>
              <th>Edad</th>
              <th>Habitación</th>
              <th>Estado</th>
              <th aria-label="Acciones"></th>
            </tr>
          </thead>
          <tbody>
            {pacientes.map((paciente) => (
              <tr key={paciente.id}>
                <td>
                  <div className="tabla__paciente">
                    <span className="avatar">{paciente.avatarIniciales}</span>
                    <div>
                      <strong>{paciente.nombreCompleto}</strong>
                      <small>{paciente.diagnosticoPrincipal}</small>
                    </div>
                  </div>
                </td>
                <td>{paciente.cedula}</td>
                <td>{paciente.edad} años</td>
                <td>{paciente.habitacion}</td>
                <td>
                  <span className={CLASE_ESTADO[paciente.estado]}>{paciente.estado}</span>
                </td>
                <td className="tabla__acciones">
                  <button
                    type="button"
                    className="boton boton--negro boton--pequeno"
                    onClick={() => seleccionarPaciente(paciente)}
                  >
                    Registrar
                  </button>
                </td>
              </tr>
            ))}

            {pacientes.length === 0 && (
              <tr>
                <td colSpan={6} className="tabla__vacio">
                  No se encontraron residentes que coincidan con “{query}”.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
