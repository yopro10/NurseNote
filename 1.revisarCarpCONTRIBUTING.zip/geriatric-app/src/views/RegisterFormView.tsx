import { FormEvent, useState } from 'react';
import { useApp } from '../context/AppContext';
import ConfirmationModal from '../components/ConfirmationModal';
import type { RegistroDatos, TipoRegistroClinico } from '../types';

const HOY = () => new Date().toISOString().slice(0, 10);
const AHORA = () => new Date().toTimeString().slice(0, 5);

export default function RegisterFormView() {
  const {
    pacienteSeleccionado,
    moduloSeleccionado,
    registrosPacienteActual,
    guardarRegistro,
    cargando,
    seleccionarModulo,
    usuarioActual,
  } = useApp();

  const tipo: TipoRegistroClinico = moduloSeleccionado ?? 'Notas de Enfermería';

  const [datos, setDatos] = useState<RegistroDatos>({});
  const [observaciones, setObservaciones] = useState('');
  const [modalAbierto, setModalAbierto] = useState(false);
  const [guardadoExitoso, setGuardadoExitoso] = useState(false);

  if (!pacienteSeleccionado) return null;

  const actualizarDato = (campo: keyof RegistroDatos, valor: string) => {
    setDatos((prev) => ({
      ...prev,
      [campo]: valor === '' ? undefined : ['frecuenciaCardiaca', 'temperatura', 'saturacionOxigeno', 'frecuenciaRespiratoria', 'glucosa'].includes(campo)
        ? Number(valor)
        : valor,
    }));
  };

  const manejarEnvio = (e: FormEvent) => {
    e.preventDefault();
    setModalAbierto(true);
  };

  const confirmarGuardado = async () => {
    await guardarRegistro({
      pacienteId: pacienteSeleccionado.id,
      tipo,
      fecha: HOY(),
      hora: AHORA(),
      datos,
      observaciones,
    });
    setModalAbierto(false);
    setDatos({});
    setObservaciones('');
    setGuardadoExitoso(true);
    setTimeout(() => setGuardadoExitoso(false), 3500);
  };

  return (
    <div className="registro-vista">
      <div className="registro-vista__cabecera">
        <button type="button" className="enlace-volver" onClick={() => seleccionarModulo(tipo)}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M15 18l-6-6 6-6" />
          </svg>
          Lista de pacientes
        </button>

        <div className="registro-vista__paciente">
          <span className="avatar avatar--grande">{pacienteSeleccionado.avatarIniciales}</span>
          <div>
            <h2>{pacienteSeleccionado.nombreCompleto}</h2>
            <p>
              CC {pacienteSeleccionado.cedula} · {pacienteSeleccionado.edad} años · Habitación{' '}
              {pacienteSeleccionado.habitacion}
            </p>
            {pacienteSeleccionado.alergias.length > 0 && (
              <p className="registro-vista__alergias">Alergias: {pacienteSeleccionado.alergias.join(', ')}</p>
            )}
          </div>
        </div>
      </div>

      {guardadoExitoso && (
        <div className="alerta alerta--exito" role="status">
          Registro guardado correctamente.
        </div>
      )}

      <div className="registro-vista__cuerpo">
        <form className="tarjeta-formulario" onSubmit={manejarEnvio}>
          <h3>{tipo}</h3>

          {tipo === 'Signos Vitales' && (
            <div className="grid-campos">
              <label className="campo">
                <span>Presión arterial (mmHg)</span>
                <input
                  type="text"
                  placeholder="120/80"
                  value={datos.presionArterial ?? ''}
                  onChange={(e) => actualizarDato('presionArterial', e.target.value)}
                  required
                />
              </label>
              <label className="campo">
                <span>Frecuencia cardíaca (lpm)</span>
                <input
                  type="number"
                  value={datos.frecuenciaCardiaca ?? ''}
                  onChange={(e) => actualizarDato('frecuenciaCardiaca', e.target.value)}
                  required
                />
              </label>
              <label className="campo">
                <span>Temperatura (°C)</span>
                <input
                  type="number"
                  step="0.1"
                  value={datos.temperatura ?? ''}
                  onChange={(e) => actualizarDato('temperatura', e.target.value)}
                  required
                />
              </label>
              <label className="campo">
                <span>Saturación de O₂ (%)</span>
                <input
                  type="number"
                  value={datos.saturacionOxigeno ?? ''}
                  onChange={(e) => actualizarDato('saturacionOxigeno', e.target.value)}
                  required
                />
              </label>
              <label className="campo">
                <span>Frecuencia respiratoria (rpm)</span>
                <input
                  type="number"
                  value={datos.frecuenciaRespiratoria ?? ''}
                  onChange={(e) => actualizarDato('frecuenciaRespiratoria', e.target.value)}
                />
              </label>
              <label className="campo">
                <span>Glucosa (mg/dL)</span>
                <input
                  type="number"
                  value={datos.glucosa ?? ''}
                  onChange={(e) => actualizarDato('glucosa', e.target.value)}
                />
              </label>
            </div>
          )}

          {tipo === 'Administración de Medicamentos' && (
            <div className="grid-campos">
              <label className="campo">
                <span>Medicamento</span>
                <input
                  type="text"
                  placeholder="Losartán 50mg"
                  value={datos.nombreMedicamento ?? ''}
                  onChange={(e) => actualizarDato('nombreMedicamento', e.target.value)}
                  required
                />
              </label>
              <label className="campo">
                <span>Dosis</span>
                <input
                  type="text"
                  placeholder="1 tableta"
                  value={datos.dosisMedicamento ?? ''}
                  onChange={(e) => actualizarDato('dosisMedicamento', e.target.value)}
                  required
                />
              </label>
              <label className="campo">
                <span>Vía de administración</span>
                <input
                  type="text"
                  placeholder="Oral"
                  value={datos.viaAdministracion ?? ''}
                  onChange={(e) => actualizarDato('viaAdministracion', e.target.value)}
                  required
                />
              </label>
            </div>
          )}

          {(tipo === 'Notas de Enfermería' || tipo === 'Control de Hogar') && (
            <label className="campo">
              <span>{tipo === 'Notas de Enfermería' ? 'Nota de evolución' : 'Novedad del hogar'}</span>
              <textarea
                rows={4}
                placeholder="Describe el estado general, comportamiento o novedades del residente…"
                value={datos.notaLibre ?? ''}
                onChange={(e) => actualizarDato('notaLibre', e.target.value)}
                required
              />
            </label>
          )}

          <label className="campo">
            <span>Observaciones adicionales</span>
            <textarea
              rows={3}
              placeholder="Opcional"
              value={observaciones}
              onChange={(e) => setObservaciones(e.target.value)}
            />
          </label>

          <div className="tarjeta-formulario__pie">
            <span>
              Registrado por <strong>{usuarioActual?.nombreCompleto}</strong> · {new Date().toLocaleString('es-CO')}
            </span>
            <button type="submit" className="boton boton--verde boton--grande">
              Guardar
            </button>
          </div>
        </form>

        <div className="tarjeta-historial">
          <h3>Historial de {tipo.toLowerCase()}</h3>
          <div className="tabla-contenedor tabla-contenedor--historial">
            <table className="tabla tabla--compacta">
              <thead>
                <tr>
                  <th>Fecha</th>
                  <th>Hora</th>
                  <th>Autor</th>
                  <th>Detalle</th>
                </tr>
              </thead>
              <tbody>
                {registrosPacienteActual
                  .filter((r) => r.tipo === tipo)
                  .map((registro) => (
                    <tr key={registro.id}>
                      <td>{new Date(`${registro.fecha}T00:00:00`).toLocaleDateString('es-CO')}</td>
                      <td>{registro.hora}</td>
                      <td>{registro.autorNombre}</td>
                      <td>{describirRegistro(registro.datos)}</td>
                    </tr>
                  ))}

                {registrosPacienteActual.filter((r) => r.tipo === tipo).length === 0 && (
                  <tr>
                    <td colSpan={4} className="tabla__vacio">
                      Aún no hay registros de este tipo para este residente.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <ConfirmationModal
        abierto={modalAbierto}
        titulo="¿Estás segura de guardar?"
        mensaje="Este registro quedará asociado permanentemente al historial clínico del residente."
        textoAceptar="ACEPTAR"
        cargando={cargando}
        onAceptar={confirmarGuardado}
        onCancelar={() => setModalAbierto(false)}
      />
    </div>
  );
}

function describirRegistro(datos: RegistroDatos): string {
  if (datos.presionArterial) {
    return `PA ${datos.presionArterial} · FC ${datos.frecuenciaCardiaca ?? '—'} lpm · Temp ${datos.temperatura ?? '—'}°C · SatO₂ ${datos.saturacionOxigeno ?? '—'}%`;
  }
  if (datos.nombreMedicamento) {
    return `${datos.nombreMedicamento} · ${datos.dosisMedicamento ?? ''} · ${datos.viaAdministracion ?? ''}`;
  }
  return datos.notaLibre ?? '—';
}
