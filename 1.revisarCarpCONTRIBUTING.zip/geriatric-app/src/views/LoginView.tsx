import { FormEvent, useState } from 'react';
import { useApp } from '../context/AppContext';

export default function LoginView() {
  const { iniciarSesion, cargando, error, limpiarError } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const manejarEnvio = (e: FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) return;
    iniciarSesion(email, password);
  };

  return (
    <div className="login-pantalla">
      <div className="login-ilustracion">
        <div className="login-ilustracion__contenido">
          <svg viewBox="0 0 200 200" width="140" height="140" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="100" cy="100" r="96" stroke="rgba(255,255,255,0.25)" strokeWidth="2" />
            <path
              d="M60 110c0-22 18-40 40-40s40 18 40 40"
              stroke="white"
              strokeWidth="4"
              strokeLinecap="round"
            />
            <circle cx="100" cy="60" r="18" fill="white" />
            <path d="M40 150c14-10 34-16 60-16s46 6 60 16" stroke="white" strokeWidth="4" strokeLinecap="round" />
            <path d="M100 118v24M88 130h24" stroke="white" strokeWidth="4" strokeLinecap="round" />
          </svg>
          <h2>Cuidado que se nota en cada turno</h2>
          <p>
            Centraliza notas de enfermería, signos vitales y medicamentos de cada residente en un solo
            lugar, para que el equipo asistencial nunca pierda de vista lo importante.
          </p>
        </div>
      </div>

      <div className="login-panel">
        <form className="login-formulario" onSubmit={manejarEnvio}>
          <div className="login-formulario__encabezado">
            <span className="login-formulario__marca">+ SIG Geriátrico</span>
            <h1>Inicia sesión</h1>
            <p>Ingresa con tu correo institucional para continuar.</p>
          </div>

          {error && (
            <div className="alerta alerta--error" role="alert">
              <span>{error}</span>
              <button type="button" onClick={limpiarError} aria-label="Cerrar alerta">
                ×
              </button>
            </div>
          )}

          <label className="campo">
            <span>Correo institucional</span>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="maria.garcia@geriatric.com"
              autoComplete="username"
              required
            />
          </label>

          <label className="campo">
            <span>Contraseña</span>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete="current-password"
              required
            />
          </label>

          <button type="submit" className="boton boton--negro boton--bloque boton--grande" disabled={cargando}>
            {cargando ? 'Ingresando…' : 'Iniciar Sesión'}
          </button>

          <div className="login-formulario__demo">
            <p>Credenciales de demostración</p>
            <ul>
              <li>
                <strong>Enfermera:</strong> maria.garcia@geriatric.com / enfermera123
              </li>
              <li>
                <strong>Jefe Enfermería:</strong> carlos.rodriguez@geriatric.com / jefe123
              </li>
              <li>
                <strong>Administrador:</strong> admin@geriatric.com / admin123
              </li>
            </ul>
          </div>
        </form>
      </div>
    </div>
  );
}
