import { AppProvider, useApp } from './context/AppContext';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import LoginView from './views/LoginView';
import DashboardView from './views/DashboardView';
import PatientListView from './views/PatientListView';
import RegisterFormView from './views/RegisterFormView';

/**
 * Enrutador principal de la SPA.
 * No se usa una librería de enrutamiento externa: el "router" es el
 * estado `vista` del AppContext, que decide qué vista renderizar dentro
 * del layout maestro sin recargar la página.
 */
function EnrutadorPrincipal() {
  const { vista, cargandoSesion, usuarioActual } = useApp();

  if (cargandoSesion) {
    return (
      <div className="pantalla-carga">
        <div className="spinner" />
        <p>Cargando sesión…</p>
      </div>
    );
  }

  if (!usuarioActual) {
    return <LoginView />;
  }

  return (
    <div className="layout-maestro">
      <Sidebar />
      <div className="layout-maestro__contenido">
        <Header />
        <main className="layout-maestro__area-trabajo">
          {vista === 'dashboard' && <DashboardView />}
          {vista === 'pacientes' && <PatientListView />}
          {vista === 'registro' && <RegisterFormView />}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <EnrutadorPrincipal />
    </AppProvider>
  );
}
