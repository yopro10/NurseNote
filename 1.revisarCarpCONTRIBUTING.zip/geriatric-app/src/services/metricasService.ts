import type { Metricas } from '../types';
import { getPacientes } from './pacienteService';
import { getMedicamentosVencidos, getMedicamentosBajoStock } from './medicamentoService';
import { getNotas } from './pacienteService';

/**
 * ============================================================================
 * SERVICIO DE MÉTRICAS - CÁLCULOS PARA DASHBOARD
 * ============================================================================
 */

export async function getMetricasDashboard(): Promise<Metricas> {
  try {
    const [pacientes, vencidos, bajoStock, notas] = await Promise.all([
      getPacientes(),
      getMedicamentosVencidos(),
      getMedicamentosBajoStock(10),
      getNotas()
    ]);

    const hoy = new Date().toISOString().split('T')[0];
    const notasHoy = notas.filter(nota => 
      nota.fecha_registro.startsWith(hoy)
    );

    return {
      totalPacientes: pacientes.length,
      pacientesCriticos: pacientes.filter(p => 
        p.alergias?.includes('crítico') || p.enfermedades_cronicas?.includes('grave')
      ).length,
      pacientesEnObservacion: Math.floor(pacientes.length * 0.3), // Estimación
      registrosHoy: notasHoy.length,
      medicamentosVencidos: vencidos.total,
      medicamentosBajoStock: bajoStock.total,
    };
  } catch (error) {
    console.error('Error al obtener métricas:', error);
    return {
      totalPacientes: 0,
      pacientesCriticos: 0,
      pacientesEnObservacion: 0,
      registrosHoy: 0,
      medicamentosVencidos: 0,
      medicamentosBajoStock: 0,
    };
  }
}