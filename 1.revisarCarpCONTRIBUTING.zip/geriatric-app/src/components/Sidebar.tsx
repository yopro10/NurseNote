import { useApp } from '../context/AppContext';
import type { TipoRegistroClinico } from '../types';

interface ItemMenu {
  id: 'dashboard' | TipoRegistroClinico;
  etiqueta: string;
  icono: JSX.Element;
}

function IconoDashboard() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <rect x="3" y="3" width="7" height="9" rx="1.5" />
      <rect x="14" y="3" width="7" height="5" rx="1.5" />
      <rect x="14" y="12" width="7" height="9" rx="1.5" />
      <rect x="3" y="16" width="7" height="5" rx="1.5" />
    </svg>
  );
}

function IconoNotas() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" />
      <path d="M14 3v5h5" />
      <path d="M9 13h6M9 17h6" />
    </svg>
  );
}

function IconoVitales() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M3 12h4l2-6 4 12 2-6h6" />
    </svg>
  );
}

function IconoMedicamentos() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <rect x="3.5" y="3.5" width="17" height="17" rx="4" />
      <path d="M8 12h8M12 8v8" />
    </svg>
  );
}

function IconoHogar() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M3 11.5 12 4l9 7.5" />
      <path d="M5 10v9a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1v-9" />
    </svg>
  );
}

const ITEMS_MENU: ItemMenu[] = [
  { id: 'dashboard', etiqueta: 'Menú principal', icono: <IconoDashboard /> },
  { id: 'Notas de Enfermería', etiqueta: 'Notas de Enfermería', icono: <IconoNotas /> },
  { id: 'Signos Vitales', etiqueta: 'Signos Vitales', icono: <IconoVitales /> },
  { id: 'Administración de Medicamentos', etiqueta: 'Medicamentos', icono: <IconoMedicamentos /> },
  { id: 'Control de Hogar', etiqueta: 'Gestión del Hogar', icono: <IconoHogar /> },
];

export default function Sidebar() {
  const { vista, moduloSeleccionado, irADashboard, seleccionarModulo, hogarActual } = useApp();

  const esActivo = (id: ItemMenu['id']) => {
    if (id === 'dashboard') return vista === 'dashboard';
    return moduloSeleccionado === id && (vista === 'pacientes' || vista === 'registro');
  };

  return (
    <aside className="sidebar">
      <div className="sidebar__marca">
        <div className="sidebar__marca-icono">+</div>
        <div className="sidebar__marca-texto">
          <span className="sidebar__marca-titulo">SIG Geriátrico</span>
          <span className="sidebar__marca-subtitulo">{hogarActual?.nombre ?? 'Cargando hogar…'}</span>
        </div>
      </div>

      <nav className="sidebar__nav" aria-label="Navegación principal">
        {ITEMS_MENU.map((item) => (
          <button
            key={item.id}
            type="button"
            className={`sidebar__item ${esActivo(item.id) ? 'sidebar__item--activo' : ''}`}
            onClick={() => (item.id === 'dashboard' ? irADashboard() : seleccionarModulo(item.id))}
          >
            <span className="sidebar__item-icono">{item.icono}</span>
            <span>{item.etiqueta}</span>
          </button>
        ))}
      </nav>

      <div className="sidebar__pie">
        <p>Prototipo · Uso académico</p>
      </div>
    </aside>
  );
}
