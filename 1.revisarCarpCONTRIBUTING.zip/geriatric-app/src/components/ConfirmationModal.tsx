interface ConfirmationModalProps {
  abierto: boolean;
  titulo: string;
  mensaje: string;
  textoAceptar?: string;
  textoCancelar?: string;
  cargando?: boolean;
  variante?: 'exito' | 'peligro';
  onAceptar: () => void;
  onCancelar: () => void;
}

export default function ConfirmationModal({
  abierto,
  titulo,
  mensaje,
  textoAceptar = 'ACEPTAR',
  textoCancelar = 'Cancelar',
  cargando = false,
  variante = 'exito',
  onAceptar,
  onCancelar,
}: ConfirmationModalProps) {
  if (!abierto) return null;

  return (
    <div className="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="modal-titulo">
      <div className="modal-tarjeta">
        <div className={`modal-tarjeta__icono modal-tarjeta__icono--${variante}`}>
          {variante === 'exito' ? (
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
              <path d="M9 12.5 11.2 15 16 9" />
            </svg>
          ) : (
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
              <path d="M12 9v4M12 17h.01" />
              <circle cx="12" cy="12" r="9" />
            </svg>
          )}
        </div>

        <h2 id="modal-titulo">{titulo}</h2>
        <p>{mensaje}</p>

        <div className="modal-tarjeta__acciones">
          <button type="button" className="boton boton--fantasma" onClick={onCancelar} disabled={cargando}>
            {textoCancelar}
          </button>
          <button
            type="button"
            className={`boton ${variante === 'exito' ? 'boton--verde' : 'boton--negro'}`}
            onClick={onAceptar}
            disabled={cargando}
          >
            {cargando ? 'Guardando…' : textoAceptar}
          </button>
        </div>
      </div>
    </div>
  );
}
