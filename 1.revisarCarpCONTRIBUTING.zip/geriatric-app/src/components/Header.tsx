import { useState } from 'react';
import { useApp } from '../context/AppContext';

const TITULOS_VISTA: Record<string, string> = {
  dashboard: 'Menú principal',
  pacientes: 'Pacientes activos',
  registro: 'Registro clínico',
};

export default function Header() {
  const { usuarioActual, metricas, vista, cerrarSesion } = useApp();
  const [perfilAbierto, setPerfilAbierto] = useState(false);

  if (!usuarioActual) return null;

  return (
    <header className="header">
      <div className="header__titulo">
        <h1>{TITULOS_VISTA[vista] ?? 'SIG Geriátrico'}</h1>
        <p>{new Date().toLocaleDateString('es-CO', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</p>
      </div>

      <div className="header__derecha">
        {metricas && (
          <div className="header__metricas">
            <div className="metrica-flotante">
              <span className="metrica-flotante__valor">{metricas.totalPacientes}</span>
              <span className="metrica-flotante__etiqueta">Pacientes</span>
            </div>
            <div className="metrica-flotante metrica-flotante--alerta">
              <span className="metrica-flotante__valor">{metricas.pacientesCriticos}</span>
              <span className="metrica-flotante__etiqueta">Críticos</span>
            </div>
            <div className="metrica-flotante">
              <span className="metrica-flotante__valor">{metricas.registrosHoy}</span>
              <span className="metrica-flotante__etiqueta">Registros hoy</span>
            </div>
          </div>
        )}

        <div className="header__perfil">
          <button
            type="button"
            className="header__perfil-boton"
            onClick={() => setPerfilAbierto((v) => !v)}
            aria-expanded={perfilAbierto}
          >
            <span className="avatar">{usuarioActual.avatarIniciales}</span>
            <span className="header__perfil-info">
              <strong>{usuarioActual.nombreCompleto}</strong>
              <small>{usuarioActual.cargo}</small>
            </span>
          </button>

          {perfilAbierto && (
            <>
              <div className="overlay-click" onClick={() => setPerfilAbierto(false)} />
              <div className="header__perfil-menu">
                <div className="header__perfil-menu-cabecera">
                  <span className="avatar avatar--grande">{usuarioActual.avatarIniciales}</span>
                  <div>
                    <strong>{usuarioActual.nombreCompleto}</strong>
                    <small>{usuarioActual.email}</small>
                  </div>
                </div>

                <dl className="header__perfil-datos">
                  <div>
                    <dt>Rol</dt>
                    <dd>{usuarioActual.rol}</dd>
                  </div>
                  <div>
                    <dt>Turno</dt>
                    <dd>{usuarioActual.turno}</dd>
                  </div>
                  <div>
                    <dt>Ingreso</dt>
                    <dd>{new Date(usuarioActual.fechaIngreso).toLocaleDateString('es-CO')}</dd>
                  </div>
                  {metricas && (
                    <div>
                      <dt>Ocupación del hogar</dt>
                      <dd>{metricas.ocupacion}%</dd>
                    </div>
                  )}
                </dl>

                <button type="button" className="boton boton--negro boton--bloque" onClick={cerrarSesion}>
                  Cerrar sesión
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
