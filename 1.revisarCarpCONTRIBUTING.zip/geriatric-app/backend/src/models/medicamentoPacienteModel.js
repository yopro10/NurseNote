import pool from '../config/database.js';

export class MedicamentoPacienteModel {
  static async create({ 
    paciente_id, 
    medicamento_id, 
    dosis_prescrita,
    frecuencia,
    via_administracion,
    fecha_inicio,
    fecha_fin,
    observaciones
  }) {
    const query = `
      INSERT INTO medicamentos_pacientes (
        paciente_id, medicamento_id, dosis_prescrita, frecuencia,
        via_administracion, fecha_inicio, fecha_fin, observaciones, activo
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true)
      RETURNING *
    `;
    const values = [
      paciente_id, medicamento_id, dosis_prescrita, frecuencia,
      via_administracion, fecha_inicio, fecha_fin, observaciones
    ];
    const result = await pool.query(query, values);
    return result.rows[0];
  }

  static async findById(id) {
    const query = `
      SELECT mp.*, m.nombre as medicamento_nombre, m.presentacion,
             p.nombre as paciente_nombre, p.apellido as paciente_apellido
      FROM medicamentos_pacientes mp
      JOIN medicamentos m ON mp.medicamento_id = m.id
      JOIN pacientes p ON mp.paciente_id = p.id
      WHERE mp.id = $1
    `;
    const result = await pool.query(query, [id]);
    return result.rows[0];
  }

  static async getByPaciente(pacienteId) {
    const query = `
      SELECT mp.*, m.nombre as medicamento_nombre, m.presentacion, m.dosis as medicamento_dosis,
             p.nombre as paciente_nombre, p.apellido as paciente_apellido
      FROM medicamentos_pacientes mp
      JOIN medicamentos m ON mp.medicamento_id = m.id
      JOIN pacientes p ON mp.paciente_id = p.id
      WHERE mp.paciente_id = $1 AND mp.activo = true
      ORDER BY mp.fecha_inicio DESC
    `;
    const result = await pool.query(query, [pacienteId]);
    return result.rows;
  }

  static async getByMedicamento(medicamentoId) {
    const query = `
      SELECT mp.*, m.nombre as medicamento_nombre, m.presentacion,
             p.nombre as paciente_nombre, p.apellido as paciente_apellido
      FROM medicamentos_pacientes mp
      JOIN medicamentos m ON mp.medicamento_id = m.id
      JOIN pacientes p ON mp.paciente_id = p.id
      WHERE mp.medicamento_id = $1 AND mp.activo = true
      ORDER BY mp.fecha_inicio DESC
    `;
    const result = await pool.query(query, [medicamentoId]);
    return result.rows;
  }

  static async getAll(filtros = {}) {
    let query = `
      SELECT mp.*, m.nombre as medicamento_nombre, m.presentacion,
             p.nombre as paciente_nombre, p.apellido as paciente_apellido
      FROM medicamentos_pacientes mp
      JOIN medicamentos m ON mp.medicamento_id = m.id
      JOIN pacientes p ON mp.paciente_id = p.id
      WHERE mp.activo = true
    `;
    const values = [];
    let paramCount = 1;

    if (filtros.paciente_id) {
      query += ` AND mp.paciente_id = $${paramCount}`;
      values.push(filtros.paciente_id);
      paramCount++;
    }

    if (filtros.medicamento_id) {
      query += ` AND mp.medicamento_id = $${paramCount}`;
      values.push(filtros.medicamento_id);
      paramCount++;
    }

    query += ' ORDER BY mp.fecha_inicio DESC';
    const result = await pool.query(query, values);
    return result.rows;
  }

  static async update(id, datos) {
    const campos = [];
    const values = [];
    let paramCount = 1;

    const camposPermitidos = [
      'dosis_prescrita', 'frecuencia', 'via_administracion',
      'fecha_inicio', 'fecha_fin', 'observaciones'
    ];

    for (const campo of camposPermitidos) {
      if (datos[campo] !== undefined) {
        campos.push(`${campo} = $${paramCount}`);
        values.push(datos[campo]);
        paramCount++;
      }
    }

    if (campos.length === 0) {
      return null;
    }

    values.push(id);
    const query = `
      UPDATE medicamentos_pacientes
      SET ${campos.join(', ')}
      WHERE id = $${paramCount}
      RETURNING *
    `;

    const result = await pool.query(query, values);
    return result.rows[0];
  }

  static async delete(id) {
    const query = `
      UPDATE medicamentos_pacientes
      SET activo = false, fecha_fin = NOW()
      WHERE id = $1
      RETURNING *
    `;
    const result = await pool.query(query, [id]);
    return result.rows[0];
  }

  static async getMedicamentosActivosPorPaciente(pacienteId) {
    const query = `
      SELECT mp.*, m.nombre as medicamento_nombre, m.presentacion, m.dosis as medicamento_dosis,
             m.cantidad_disponible, m.fecha_caducidad
      FROM medicamentos_pacientes mp
      JOIN medicamentos m ON mp.medicamento_id = m.id
      WHERE mp.paciente_id = $1 
      AND mp.activo = true
      AND (mp.fecha_fin IS NULL OR mp.fecha_fin > NOW())
      ORDER BY mp.fecha_inicio DESC
    `;
    const result = await pool.query(query, [pacienteId]);
    return result.rows;
  }
}