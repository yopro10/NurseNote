import express from 'express';
import { PacienteController } from '../controllers/pacienteController.js';
import { authenticateToken, isEnfermeraOrAdmin } from '../middleware/authMiddleware.js';

const router = express.Router();

// Todas las rutas requieren autenticación
router.use(authenticateToken);

// Rutas públicas para enfermeras y administradores
router.post('/', isEnfermeraOrAdmin, PacienteController.create);
router.get('/', isEnfermeraOrAdmin, PacienteController.getAll);
router.get('/:id', isEnfermeraOrAdmin, PacienteController.getById);
router.put('/:id', isEnfermeraOrAdmin, PacienteController.update);
router.delete('/:id', isEnfermeraOrAdmin, PacienteController.delete);
router.get('/habitacion/:habitacion', isEnfermeraOrAdmin, PacienteController.getByHabitacion);

export default router;