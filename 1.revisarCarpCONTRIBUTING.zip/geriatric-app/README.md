# SIG · Sistema de Gestión de Hogares Geriátricos (Prototipo)

Prototipo frontend de alta fidelidad para la gestión de un hogar geriátrico:
notas de enfermería, signos vitales, medicamentos y control del hogar.

## Stack

- **Frontend:** React 18 + TypeScript + Vite
- **Backend (simulado):** los archivos en `src/services/` están escritos como
  si llamaran a endpoints REST de Node.js (`GET /api/pacientes`,
  `POST /api/registros`, etc.). Cada función es `async` y devuelve una
  `Promise`, por lo que reemplazar su implementación interna por un
  `fetch()` real no requiere tocar ninguna vista.
- **Base de datos (simulada):** `src/services/authService.ts` expone
  `getDB()` / `setDB()`, que persisten un único documento JSON en
  `localStorage` bajo la clave `sig_hogares_geriatricos_db_v1`, emulando
  las tablas `usuarios`, `hogares`, `pacientes` y `registros` de PostgreSQL.

## Arquitectura (Clean Architecture adaptada a React)

```
types/      → Modelos de dominio (equivalentes a las entidades de PostgreSQL)
services/   → Model: acceso a datos + "llamadas API" simuladas
context/    → Controller: AppContext orquesta los servicios y expone estado
components/ → Piezas de UI reutilizables (Sidebar, Header, Modal)
views/      → View: pantallas completas (Login, Dashboard, Pacientes, Registro)
```

## Cómo ejecutarlo

```bash
npm install
npm run dev
```

Abre `http://localhost:5173`.

## Credenciales de demostración

| Rol        | Usuario (cédula o correo)      | Contraseña |
|------------|---------------------------------|------------|
| Enfermera  | `1020304050` / laura.gomez@sanrafael.co | `123456` |
| Auxiliar   | `80234567` / carlos.pena@sanrafael.co   | `123456` |

## Flujo funcional implementado

1. **Login** → autentica contra la base simulada y persiste la sesión.
2. **Dashboard** → 4 tarjetas de módulo (Notas de Enfermería, Signos Vitales,
   Medicamentos, Gestión del Hogar) + métricas del hogar.
3. **Lista de pacientes** → tabla con buscador funcional por nombre o cédula
   (con normalización de tildes/mayúsculas).
4. **Registrar** → abre el formulario específico del módulo seleccionado.
5. **Guardar** → dispara el modal "¿Estás segura de guardar?"; al aceptar,
   se actualiza el Context (y la "base de datos" en `localStorage`) y la
   tabla de historial se refresca de inmediato.
6. **Perfil de usuario** (en la cabecera) → métricas personales y
   **Cerrar sesión**, que regresa al Login.

## Siguientes pasos hacia producción

- Reemplazar el cuerpo de las funciones en `services/*.ts` por llamadas
  `fetch()`/`axios` a una API Node.js real.
- Sustituir `getDB()`/`setDB()` por un ORM (Prisma/TypeORM) sobre PostgreSQL.
- Añadir manejo de JWT/refresh tokens en `authService.ts`.
- Añadir validaciones de formulario más estrictas y control de roles por ruta.
